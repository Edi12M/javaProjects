package HoteMenagament.src;

import Hotel1.src.Booking;
import Hotel1.src.Room;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class DAO {
    public static final String FILE_PATH_BOOKINGS = "booking.dat";
    private static final File DATA_FILE_BOOKINGS = new File(FILE_PATH_BOOKINGS);
    public static final String FILE_PATH_ROOMS = "rooms.dat";
    private static final File DATA_FILE_ROOMS = new File(FILE_PATH_ROOMS);

    private final ObservableList<Booking> bookings = FXCollections.observableArrayList();
    private final ObservableList<Room> roomsAvailable = FXCollections.observableArrayList();

    public ObservableList<Booking> getAllBookings() {
        if (bookings.isEmpty()) {
            loadBookingsFromFile();
        }
        return bookings;
    }

    public ObservableList<Room> getAllRooms() {
        if (roomsAvailable.isEmpty()) {
            loadRoomsFromFile();
        }
        return roomsAvailable;
    }

    private void loadBookingsFromFile() {
        if (!DATA_FILE_BOOKINGS.exists()) return;
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(DATA_FILE_BOOKINGS))) {
            List<Booking> loadedBookings = (List<Booking>) inputStream.readObject();
            bookings.addAll(loadedBookings);
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error loading bookings: " + ex.getMessage());
        }
    }

    private void loadRoomsFromFile() {
        if (!DATA_FILE_ROOMS.exists()) return;
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(DATA_FILE_ROOMS))) {
            List<Room> loadedRooms = (List<Room>) inputStream.readObject();
            roomsAvailable.addAll(loadedRooms);
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error loading rooms: " + ex.getMessage());
        }
    }

    public boolean create(Booking booking) {

        //convert localDate to Date
        Date checkInDate = java.sql.Date.valueOf(booking.getCheckIn());
        Date checkOutDate = java.sql.Date.valueOf(booking.getCheckOut());


        if (isRoomAvailable(booking.getRoom(), checkInDate, checkOutDate)) {
            bookings.add(booking);
            roomsAvailable.remove(booking.getRoom());
            return saveAllBookings() && saveAllRooms();
        }
        System.out.println("Room is not available for booking.");
        return false;
    }

    public boolean delete(Booking booking) {
        if (bookings.remove(booking)) {
            roomsAvailable.add(booking.getRoom());
            return saveAllBookings() && saveAllRooms();
        }
        return false;
    }

    public boolean deleteAll(List<Booking> bookingsToRemove) {
        for (Booking booking : bookingsToRemove) {
            if (bookings.remove(booking)) {
                roomsAvailable.add(booking.getRoom());
            }
        }
        return saveAllBookings() && saveAllRooms();
    }

    private boolean saveAllBookings() {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(DATA_FILE_BOOKINGS))) {
            outputStream.writeObject(new ArrayList<>(bookings));
            return true;
        } catch (IOException ex) {
            System.out.println("Error saving bookings: " + ex.getMessage());
            return false;
        }
    }

    private boolean saveAllRooms() {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(DATA_FILE_ROOMS))) {
            outputStream.writeObject(new ArrayList<>(roomsAvailable));
            return true;
        } catch (IOException ex) {
            System.out.println("Error saving rooms: " + ex.getMessage());
            return false;
        }
    }

    public boolean isRoomAvailable(Room room, Date startDate, Date endDate) {

        for (Booking booking : bookings) {

            //convert localDate to Date
            Date checkInDate = java.sql.Date.valueOf(booking.getCheckIn());
            Date checkOutDate = java.sql.Date.valueOf(booking.getCheckOut());

            if (booking.getRoom().equals(room) && datesOverlap(checkInDate, checkOutDate, startDate, endDate)) {
                return false;
            }
        }
        return true;
    }

    public List<Room> getAvailableRooms(Date startDate, Date endDate) {
        return roomsAvailable.stream()
                .filter(room -> isRoomAvailable(room, startDate, endDate))
                .collect(Collectors.toList());
    }

    private boolean datesOverlap(Date start1, Date end1, Date start2, Date end2) {
        return !start1.after(end2) && !start2.after(end1);
    }
}
