package _schoolproject.page;

import HoteMenagament.src.DAO;
import Hotel1.src.*;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.ArrayList;

public class BookingController {

    private final Dashboard view;
    private final DAO bookingDao;
    private ArrayList<Room> rooms;  // Manually created list of rooms

    public Dashboard getView() {
        return view;
    }

    public BookingController() {
        this.view = new Dashboard();
        bookingDao = new DAO();
        this.view.getTableView().setItems(bookingDao.getAllBookings());
        this.view.getAddBtn().setOnAction(e -> onBookingAdd());
        this.view.getDeleteBtn().setOnAction(this::onBookingDelete);
        this.view.getInfoBtn().setOnAction(this::onBookingInfo);
        this.view.getInvoiceBtn().setOnAction(this::onBookingInvoice);

        // Manually creating rooms list
        rooms = new ArrayList<>();
        rooms.add(new Room(RoomType.SINGLE, "1"));
        rooms.add(new Room(RoomType.SINGLE, "2"));
        rooms.add(new Room(RoomType.SINGLE, "3"));
        rooms.add(new Room(RoomType.SINGLE, "4"));
        rooms.add(new Room(RoomType.SINGLE, "5"));

        rooms.add(new Room(RoomType.DOUBLE, "6"));
        rooms.add(new Room(RoomType.DOUBLE, "7"));
        rooms.add(new Room(RoomType.DOUBLE, "8"));
        rooms.add(new Room(RoomType.DOUBLE, "9"));
        rooms.add(new Room(RoomType.DOUBLE, "10"));

        rooms.add(new Room(RoomType.FAMILY, "11"));
        rooms.add(new Room(RoomType.FAMILY, "12"));
        rooms.add(new Room(RoomType.FAMILY, "13"));
        rooms.add(new Room(RoomType.FAMILY, "14"));
        rooms.add(new Room(RoomType.FAMILY, "15"));
        rooms.add(new Room(RoomType.FAMILY, "16"));
        rooms.add(new Room(RoomType.FAMILY, "17"));

        rooms.add(new Room(RoomType.DELUXE, "18"));
        rooms.add(new Room(RoomType.DELUXE, "19"));
        rooms.add(new Room(RoomType.DELUXE, "20"));
        rooms.add(new Room(RoomType.DELUXE, "21"));

        rooms.add(new Room(RoomType.SUITE, "22"));
        rooms.add(new Room(RoomType.SUITE, "23"));
        rooms.add(new Room(RoomType.SUITE, "24"));
    }

    private void onBookingDelete(ActionEvent event) {
        Booking selectedBooking = this.view.getTableView().getSelectionModel().getSelectedItem();
        Alert alert;

        if (selectedBooking == null) {
            alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("No booking selected for deletion.");
        } else if (bookingDao.delete(selectedBooking)) {
            // Set the room back to available after deleting the booking
            selectedBooking.getRoom().cancelBooking(selectedBooking.getCheckIn(), selectedBooking.getCheckOut());
            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Deleted Successfully");
            System.out.println("Deleted successfully");
        }
        //alert.show();
    }

    private void onBookingAdd() {
        Stage formStage = new Stage();
        formStage.setTitle("Add Booking");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);

        // Labels and Inputs for Guest
        Label nameLabel = new Label("Guest Name:");
        TextField nameField = new TextField();

        Label surnameLabel = new Label("Guest Surname:");
        TextField surnameField = new TextField();

        Label ageLabel = new Label("Guest Age:");
        TextField ageField = new TextField();

        Label addressLabel = new Label("Guest Address:");
        TextField addressField = new TextField();

        Label contactLabel = new Label("Guest Contact:");
        TextField contactField = new TextField();

        // Labels and inputs for Room
        Label roomTypeLabel = new Label("Room Type:");
        ComboBox<RoomType> roomTypeComboBox = new ComboBox<>();
        roomTypeComboBox.getItems().addAll(RoomType.values());

        Label roomIDLabel = new Label("Room ID:");
        ComboBox<String> roomIDComboBox = new ComboBox<>();  // ComboBox for Room IDs

        Label checkInLabel = new Label("Check-In:");
        DatePicker checkInPicker = new DatePicker();

        Label checkOutLabel = new Label("Check-Out:");
        DatePicker checkOutPicker = new DatePicker();

        Button saveButton = new Button("Save");

        // Add elements to GridPane
        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 1, 0);

        grid.add(surnameLabel, 0, 1);
        grid.add(surnameField, 1, 1);

        grid.add(ageLabel, 0, 2);
        grid.add(ageField, 1, 2);

        grid.add(addressLabel, 0, 3);
        grid.add(addressField, 1, 3);

        grid.add(contactLabel, 0, 4);
        grid.add(contactField, 1, 4);

        grid.add(checkInLabel, 0, 5);
        grid.add(checkInPicker, 1, 5);

        grid.add(checkOutLabel, 0, 6);
        grid.add(checkOutPicker, 1, 6);

        grid.add(roomTypeLabel, 0, 7);
        grid.add(roomTypeComboBox, 1, 7);

        grid.add(roomIDLabel, 0, 8);
        grid.add(roomIDComboBox, 1, 8);

        grid.add(saveButton, 1, 9);

        // Handle Room Type selection change to populate Room IDs based on selected type
        roomTypeComboBox.setOnAction(e -> {
            RoomType selectedRoomType = roomTypeComboBox.getValue();
            LocalDate checkInDate = checkInPicker.getValue();
            LocalDate checkOutDate = checkOutPicker.getValue();

            if (checkInDate != null && checkOutDate != null) {
                updateRoomIDComboBox(selectedRoomType, checkInDate, checkOutDate, roomIDComboBox);
            }
        });

        // Handle Save Button Click
        saveButton.setOnAction(e -> {
            String name = nameField.getText();
            String lastName = surnameField.getText();
            String ageText = ageField.getText();
            String address = addressField.getText();
            String contact = contactField.getText();
            RoomType roomType = roomTypeComboBox.getValue();
            String roomId = roomIDComboBox.getValue();  // Get selected Room ID
            LocalDate checkIn = checkInPicker.getValue();
            LocalDate checkOut = checkOutPicker.getValue();

            // Validate integer field for age

            int age;
            try {
                age = Integer.parseInt(ageText);
            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Please enter a valid age.");
                alert.show();
                return;
            }

            if (name.isEmpty() || lastName.isEmpty() || address.isEmpty() || contact.isEmpty() ||
                    roomId == null || roomType == null || checkIn == null || checkOut == null) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please fill all fields.");
                alert.show();
            } else {
                // Find the room by ID
                Room room = findRoomById(roomId);

                if (room == null) {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Room not found.");
                    alert.show();
                    return;
                }

                // Check if the room is available for the selected date range
                if (!room.isAvailable(checkIn, checkOut)) {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Room is not available for the selected dates.");
                    alert.show();
                    return;
                }

                // If room is available, proceed with booking
                Guest newGuest = new Guest(name, lastName, age, address, contact);
                Booking newBooking = new Booking(newGuest, room, checkIn, checkOut);

                // Mark the room as unavailable after booking
                room.bookRoom(checkIn, checkOut);

                // Add to database
                bookingDao.create(newBooking);

                // Refresh the TableView after adding the booking
                refreshTableView();

                formStage.close();
            }
        });

        Scene scene = new Scene(grid, 400, 500); // Increased scene size for better layout
        formStage.setScene(scene);
        formStage.show();
    }

    private void updateRoomIDComboBox(RoomType roomType, LocalDate checkInDate, LocalDate checkOutDate, ComboBox<String> roomIDComboBox) {
        // Clear existing Room IDs in ComboBox
        roomIDComboBox.getItems().clear();

        // Get rooms of the selected RoomType that are available for the selected dates
        ArrayList<Room> availableRooms = getAvailableRoomsByTypeAndDates(roomType, checkInDate, checkOutDate);

        // Add Room IDs to ComboBox if rooms are available
        if (!availableRooms.isEmpty()) {
            for (Room room : availableRooms) {
                roomIDComboBox.getItems().add(room.getRoomId());
            }
        } else {
            roomIDComboBox.getItems().add("No available rooms");
        }
    }

    private ArrayList<Room> getAvailableRoomsByTypeAndDates(RoomType roomType, LocalDate checkIn, LocalDate checkOut) {
        ArrayList<Room> availableRooms = new ArrayList<>();

        // Filter rooms based on the selected RoomType and the availability for the selected dates
        for (Room room : rooms) {
            if (room.getRoomType() == roomType && room.isAvailable(checkIn, checkOut)) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    private Room findRoomById(String roomId) {
        // Search for the room in the manually created rooms list
        for (Room room : rooms) {
            if (room.getRoomId().equals(roomId)) {
                return room;  // Room found, return it
            }
        }
        return null;  // Room not found
    }

    private void refreshTableView() {
        view.getTableView().setItems(bookingDao.getAllBookings());
    }

    private void onBookingInfo(ActionEvent event) {
        Booking selectedBooking = this.view.getTableView().getSelectionModel().getSelectedItem();
        Alert alert;

        if (selectedBooking == null) {
            alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("No booking selected for Invoice.");
        } else {
            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Booking Information");
            alert.setHeaderText("Details:");
            alert.setContentText(selectedBooking.toString());
            alert.show();
        }
    }

    private void onBookingInvoice(ActionEvent event) {
        Booking selectedBooking = this.view.getTableView().getSelectionModel().getSelectedItem();
        Alert alert;

        if (selectedBooking == null) {
            alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText("No booking selected for Invoice.");
        } else {
            Invoice invoice = new Invoice(selectedBooking);
            String invoiceText = invoice.printInvoice();  // Get invoice as a String

            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Invoice");
            alert.setHeaderText("Booking Invoice Details");

            // Use a TextArea to display long text properly
            TextArea textArea = new TextArea(invoiceText);
            alert.getDialogPane().setContent(textArea);
            alert.show();
        }
    }
}
