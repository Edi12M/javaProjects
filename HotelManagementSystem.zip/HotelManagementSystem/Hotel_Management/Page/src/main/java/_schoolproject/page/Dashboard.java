package _schoolproject.page;

import Hotel1.src.Booking;
import Hotel1.src.Guest;
import Hotel1.src.Room;
import Hotel1.src.RoomType;
import javafx.beans.Observable;
import javafx.beans.property.Property;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.time.LocalDate;

public class Dashboard extends BorderPane {
    private final TableView <Booking> tableView = new TableView<>();
    private final TableColumn <Booking, String> BookingColumn;
    private final TableColumn <Booking, String> roomColumn;
    private final TableColumn <Booking, LocalDate> checkInDateCol;
    private final TableColumn <Booking, LocalDate> checkOutDateCol;
    private final Button addBtn = createStyledButton("Add Booking");
    private final Button deleteBtn = createStyledButton("Delete Booking");
    private final Button invoiceBtn = createStyledButton("Invoice");
    private final Button infoBtn = createStyledButton("Info");

    public Dashboard() {
        tableView.setEditable(false);
        tableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        Label titleLabel = new Label("HOTEL ELYSIAN");
        titleLabel.setFont(Font.font("Algerian",40));
        titleLabel.setStyle("-fx-text-fill: #2C3E50; -fx-font-weight: bold; -fx-padding: 20px 0; -fx-alignment: center; -fx-background-color: #F5F5F5;");


        // Column for Guest Name
        BookingColumn = new TableColumn<>("Name");
        BookingColumn.setMinWidth(150);
        BookingColumn.setCellValueFactory(cellData ->
                new ReadOnlyObjectWrapper<>(cellData.getValue().getGuest().getName()));

// Column for Room Type
        roomColumn = new TableColumn<>("Room");
        roomColumn.setMinWidth(150);
        roomColumn.setCellValueFactory(cellData ->
                new ReadOnlyObjectWrapper<>(cellData.getValue().getRoom().getRoomId()));

        // Column for Check-in Date
        checkInDateCol = new TableColumn<>("Check-In");
        checkInDateCol.setMinWidth(150);
        checkInDateCol.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getCheckIn()));

        // Column for Check-out Date
        checkOutDateCol = new TableColumn<>("Check-Out");
        checkOutDateCol.setMinWidth(150);
        checkOutDateCol.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getCheckOut()));

        // Add columns to TableView
        tableView.getColumns().addAll(BookingColumn, roomColumn, checkInDateCol, checkOutDateCol);

//        // Table for Free Rooms
//        TableView<Room> freeRoomsTable = new TableView<>();
//
//
//// Column for Room Number
//        TableColumn<Room, String> roomNumberColumn = new TableColumn<>("Room Number");
//        roomNumberColumn.setMinWidth(150);
//        roomNumberColumn.setCellValueFactory(cellData ->
//                new ReadOnlyObjectWrapper<>(cellData.getValue().getRoomId()));
//
//// Column for Room Type
//        TableColumn<Room, RoomType> roomTypeColumn = new TableColumn<>("Room Type");
//        roomTypeColumn.setMinWidth(150);
//        roomTypeColumn.setCellValueFactory(cellData ->
//                new ReadOnlyObjectWrapper<>(cellData.getValue().getRoomType()));
//
//// Column for Availability (optional)
//        TableColumn<Room, String> availabilityColumn = new TableColumn<>("Availability");
//        availabilityColumn.setMinWidth(150);
//        availabilityColumn.setCellValueFactory(cellData ->
//                new ReadOnlyObjectWrapper<>("Available"));
//
//// Add columns to freeRoomsTable
//        freeRoomsTable.getColumns().addAll(roomNumberColumn, roomTypeColumn, availabilityColumn);


        // Button layout
        HBox buttonBox = new HBox(20, addBtn, deleteBtn, invoiceBtn, infoBtn);
        buttonBox.setPadding(new Insets(10));

        // Main layout
        VBox layout = new VBox(10, titleLabel,tableView, buttonBox);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(15));

        this.setCenter(layout);
    }



    public TableView<Booking> getTableView() {
        return tableView;
    }

    public TableColumn<Booking, String> getBookingColumn() {
        return BookingColumn;
    }

    public TableColumn<Booking, String> getRoomColumn() {
        return roomColumn;
    }

    public TableColumn<Booking, LocalDate> getCheckInDateCol() {
        return checkInDateCol;
    }

    public TableColumn<Booking, LocalDate> getCheckOutDateCol() {
        return checkOutDateCol;
    }

    public Button getAddBtn() {
        return addBtn;
    }

    public Button getDeleteBtn() {
        return deleteBtn;
    }

    public Button getInvoiceBtn() {
        return invoiceBtn;
    }



    public Button getInfoBtn() {
        return infoBtn;
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setFont(new Font("Arial Black", 15));
        button.setStyle("-fx-background-color: #1C282E; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-border-radius: 5px;");
        button.setPrefWidth(200);
        button.setOnMouseEntered(e -> button.setStyle("-fx-background-color: #A0B894; -fx-text-fill: #000000;"));
        button.setOnMouseExited(e -> button.setStyle("-fx-background-color: #1C282E; -fx-text-fill: white; -fx-padding: 10px 20px; -fx-border-radius: 5px;"));
        return button;
    }
}
