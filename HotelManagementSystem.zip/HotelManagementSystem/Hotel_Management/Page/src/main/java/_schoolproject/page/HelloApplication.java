package _schoolproject.page;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.IOException;

public class HelloApplication extends Application {
    LogInPage LogInpane = new LogInPage();
    @Override
    public void start(Stage stage) throws IOException {
        Image icon = new Image("Log.jpg");
        Scene scene = new Scene(LogInpane,700,500);
        stage.setResizable(false);
        stage.getIcons().add(icon);
        stage.setScene(scene);
        stage.setTitle("LogIn");

        stage.show();

    }



    public static void main(String[] args) {
        launch();
    }
}