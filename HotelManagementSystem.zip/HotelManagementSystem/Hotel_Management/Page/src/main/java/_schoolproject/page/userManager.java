package _schoolproject.page;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class userManager {

    private static ArrayList<Staff> staff = new ArrayList<>();

    public static void loadUsersFromFile() {
        try {
            File file = new File("staff.txt");
            Scanner scanner = new Scanner(file);

            staff.clear(); // Prevent duplicate users from being added

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(" ");
                if (parts.length == 2) {
                    String username = parts[0];
                    String password = parts[1];
                    staff.add(new Staff(username, password)); // Add user to list
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            e.printStackTrace();
        }
    }


    // Check if the entered username and password match any user in the list
    public static boolean validateCredentials(String username, String password) {
        if (username == null || username.trim().isEmpty() ||
                password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Username and password cannot be empty.");
        }

        if (staff == null) {
            throw new IllegalStateException("Staff list is not initialized.");
        }

        for (Staff s : staff) {
            try {
                if (s.getUsername().equals(username)&&s.getPassword().equals(password)) {
                    return true; // Valid credentials
                }
            } catch (IllegalArgumentException e) {
                System.err.println("Invalid data in staff validation: " + e.getMessage());
                System.out.println("bla bla");// Log but continue
            }
        }

        return false; // No valid credentials found
    }
}

