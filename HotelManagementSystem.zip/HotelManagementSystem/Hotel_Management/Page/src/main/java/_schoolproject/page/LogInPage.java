package _schoolproject.page;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class LogInPage extends GridPane {

    public LogInPage(){
        setUpView();
    }
    Button loginBtn = new Button("LogIn");
    Button signUpBtn = new Button("SignUp");
    Label usernameLabel = new Label("Username");
    TextField usernameTf = new TextField();

    Label passwordLabel = new Label("Password");
    PasswordField passwordTf = new PasswordField();





    GridPane pane = new GridPane();
    Image logo = new Image("Log.jpg");

    public Button getLoginBtn() {
        return loginBtn;
    }

    public Button getSignUpBtn() {
        return signUpBtn;
    }

    public Label getUsernameLabel() {
        return usernameLabel;
    }

    public TextField getUsernameTf() {
        return usernameTf;
    }

    public Image getLogo() {
        return logo;
    }

    public Label getErrorLabel() {
        return errorLabel;
    }

    public Label getPasswordLabel() {
        return passwordLabel;
    }

    public PasswordField getPasswordTf() {
        return passwordTf;
    }

    public GridPane getPane() {
        return pane;
    }

    public void setUpView(){
        this.setAlignment(Pos.CENTER);
        this.setPadding(new Insets(0, 10, 0, 10));
        this.setVgap(10);
        this.setHgap(10);

        // Set background image for the grid pane
        Image backgroundImg = new Image("background2.jpg");
        BackgroundImage background = new BackgroundImage(
                backgroundImg,
                BackgroundRepeat.NO_REPEAT,  // Do not repeat the image
                BackgroundRepeat.NO_REPEAT,  // Do not repeat the image
                BackgroundPosition.CENTER,   // Center the image
                new BackgroundSize(100, 100, true, true, true, false) // Scale image to fill
        );
        this.setBackground(new Background(background));

        // Add controls
        this.add(usernameLabel, 0, 0);
        this.add(usernameTf, 1, 0);
        this.add(passwordLabel, 0, 1);
        this.add(passwordTf, 1, 1);
        this.add(loginBtn,0,2);
        this.add(signUpBtn,1,2);



        usernameLabel.setTextFill(Color.BLACK);
        passwordLabel.setTextFill(Color.BLACK);
        usernameLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        passwordLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        usernameTf.setStyle("-fx-background-color: #ffffff; -fx-text-fill: #333333; -fx-font-size: 14px; -fx-padding: 5px;");
        passwordTf.setStyle("-fx-background-color: #ffffff; -fx-text-fill: #333333; -fx-font-size: 14px; -fx-padding: 5px;");

        loginBtn.setOnAction(e->handleLoginAction());
        signUpBtn.setOnAction(e->handleSignUpAction());

    }

    private Label errorLabel = new Label(); // Create a label for error messages
    private void handleLoginAction() {
        try {
            userManager.loadUsersFromFile(); // Load users before checking credentials

            String username = usernameTf.getText();
            String password = passwordTf.getText();

            if (username == null || username.trim().isEmpty() ||
                    password == null || password.trim().isEmpty()) {
                throw new IllegalArgumentException("Username and password cannot be empty.");
            }

            if (userManager.validateCredentials(username, password)) {
                System.out.println("Success");
                openNewStage();
            } else {
                showError("Invalid Username or Password");
            }
//            showError("");
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid input.. Please try again");
            System.out.println("Not valid data.. Please try again");
        } catch (Exception e) {
            showError("An unexpected error occurred.");
            e.printStackTrace();
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setTextFill(Color.DARKRED);  // Set the text color to red
        errorLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // add the error label to the layout if it's not already added
        this.add(errorLabel, 0, 3, 2, 1);
    }

    private void openNewStage() {
        // Close the login window
        Stage currentStage = (Stage) loginBtn.getScene().getWindow();
        currentStage.close();

        // Open the dashboard window
        BookingController bookingController = new BookingController(); // Create controller
        Scene dashboardScene = new Scene(bookingController.getView(), 800, 600); // Set scene

        Stage dashboardStage = new Stage();
        dashboardStage.setTitle("Hotel Dashboard");
        dashboardStage.setScene(dashboardScene);
        dashboardStage.show();



    }

    private void handleSignUpAction() {
        String username = usernameTf.getText();
        String password = passwordTf.getText();

        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            showError("Username or password cannot be empty.");
            System.out.println("Username and pass are empty");
            return;
        }

        Staff staff = new Staff(username, password);
        File file = new File("staff.txt");

        try (FileWriter fw = new FileWriter(file, true);
             PrintWriter writer = new PrintWriter(fw)) {
            writer.println(staff.toString());
            System.out.println("Sign-up successful.");
            showError("SignUp successfully");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }






}
