package Hotel1.src;

import java.util.Random;

public class Invoice {
    private final String invoiceId;
    private final Booking booking;


    //create the invoice object
    public Invoice(Booking booking) {
        this.invoiceId = generateInvoiceId();
        this.booking = booking;

    }
    //assign id's to each of the invoices
    private String generateInvoiceId() {
        Random random = new Random();
        int id = 10000 + random.nextInt(90000);
        return "INV-" + id;
    }
    //printing the invoice to be given to the guest
    public String printInvoice() {
        return
        "=================================\n"+
        "           HOTEL ELYSIAN         \n"+
        "=================================\n"+
        "Invoice ID: " + invoiceId+"\n"+
        "Guest Name: " + booking.getGuest().getName()+"\n"+
        "Room Type: " + booking.getRoom().getClass().getSimpleName()+"\n"+
        "Check-in Date: " + booking.getCheckIn()+"\n"+
        "Check-out Date: " + booking.getCheckOut()+"\n"+
        "Total Price: $" + booking.calculateTotalPrice()+"\n"+
        "=================================";

    }

    public String getInvoiceId() { return invoiceId; }
    public Booking getBooking() { return booking; }

}
