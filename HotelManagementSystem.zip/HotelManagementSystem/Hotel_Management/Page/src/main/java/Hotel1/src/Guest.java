package Hotel1.src;

import java.io.Serializable;

public class Guest implements Serializable {
    private String name;
    private String lastName;
    private int age;

    private String address;
    private String contact;

    //create a guest
    public Guest(String name, String lastName, int age,  String address, String contact) {
        this.name = name;
        this.lastName = lastName;
        this.age = age;
        this.address = address;
        this.contact = contact;

    }

    public   String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }
    //guest data to be shown
    public String toString() {
        return "Guest :"+ name + " " + lastName + " " + age + " " +" " + address + " " + contact + " ";
    }
}
