package Hotel1.src;

import java.io.Serializable;
import java.time.LocalDate;

public class Booking implements Serializable {

    private Guest guest;
    private Room room;
    private  LocalDate checkIn;
    private  LocalDate checkOut;

    // Create a booking (only if room is available)
    public Booking(Guest guest, Room room, LocalDate checkIn, LocalDate checkOut) {
        if (room.bookRoom(checkIn, checkOut)) {
            this.guest = guest;
            this.room = room;
            this.checkIn = checkIn;
            this.checkOut = checkOut;
        } else {
            throw new IllegalArgumentException("Room is not available for the selected dates.");
        }
    }

    // Change booking dates (cancels old and books new if available)
    public boolean updateBookingDates(LocalDate newCheckIn, LocalDate newCheckOut) {
        room.cancelBooking(this.checkIn, this.checkOut); // Cancel old booking

        if (room.bookRoom(newCheckIn, newCheckOut)) {
            this.checkIn = newCheckIn;
            this.checkOut = newCheckOut;
            return true;
        } else {
            room.bookRoom(this.checkIn, this.checkOut); // Restore old booking if new one fails
            return false;
        }
    }

    // Calculate total price based on number of nights
    public double calculateTotalPrice() {
        long nights = checkIn.until(checkOut).getDays();
        return nights * room.getPrice();
    }

    public Guest getGuest() { return guest; }
    public Room getRoom() { return room; }
    public  LocalDate getCheckIn() { return checkIn; }
    public  LocalDate getCheckOut() { return checkOut; }

    public String toString(){
        return guest.toString()+"\n"+
                "CheckIn Date: "+ getCheckIn() +"\n"+
                "CheckOut Date: "+ getCheckOut()+"\n"+
                "Room id: "+ getRoom().getRoomId()+"\n"+
                "Room Type: "+ getRoom().getRoomType();
    }
}
