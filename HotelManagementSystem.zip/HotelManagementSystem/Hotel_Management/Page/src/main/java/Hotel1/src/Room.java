package Hotel1.src;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Room implements Serializable {
    private final RoomType roomType;
    private final String roomId;
    private final Set<LocalDate> bookedDates = new HashSet<>();
    private boolean isAvailable;

    public Room(RoomType roomType, String roomId) {
        this.roomType = roomType;
        this.roomId = roomId;
        this.isAvailable = true; //(room available)
    }

    public RoomType getRoomType() {
        return roomType;
    }

    public String getRoomId() {
        return roomId;
    }

    public double getPrice() {
        return roomType.getPrice();
    }

    public String getRoomName() {
        return roomType.getName();
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean value) {
        this.isAvailable = value;
    }

    // Check if the room is available for a given date range
    public boolean isAvailable(LocalDate checkIn, LocalDate checkOut) {
        // Ensure the room isn't booked for any of the dates within the range
        for (LocalDate date = checkIn; !date.isAfter(checkOut); date = date.plusDays(1)) {
            if (bookedDates.contains(date)) {
                return false; // Room is already booked for one of these dates
            }
        }
        return isAvailable;
    }

    // Book the room for a specific date range
    public boolean bookRoom(LocalDate checkIn, LocalDate checkOut) {
        if (!isAvailable(checkIn, checkOut)) {
            return false; // Cannot book if already reserved
        }

        // Mark the room as unavailable and add dates to bookedDates set
        for (LocalDate date = checkIn; !date.isAfter(checkOut); date = date.plusDays(1)) {
            bookedDates.add(date);
        }

        // After booking, mark the room as unavailable
        setAvailable(false);
        return true; // Successfully booked the room
    }

    // Cancel booking for specific dates
    public void cancelBooking(LocalDate checkIn, LocalDate checkOut) {
        for (LocalDate date = checkIn; !date.isAfter(checkOut); date = date.plusDays(1)) {
            bookedDates.remove(date);
        }

        // If no dates are booked anymore, set the room as available
        if (bookedDates.isEmpty()) {
            setAvailable(true); // Room becomes available again if no bookings remain
        }
    }
}
