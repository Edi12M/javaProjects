package Hotel1.src;

import java.io.Serializable;

public enum RoomType implements Serializable {
    SINGLE("Single Room", 50.0),
    DOUBLE("Double Room", 100.0),
    FAMILY("Family Room", 200.0),
    DELUXE("Deluxe",250.0),
    SUITE("Suite", 350.0);
    private final String name;
    private final double price;

    RoomType(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}
