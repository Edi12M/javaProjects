module _schoolproject.page {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;

    opens _schoolproject.page to javafx.fxml;
    exports _schoolproject.page;
}